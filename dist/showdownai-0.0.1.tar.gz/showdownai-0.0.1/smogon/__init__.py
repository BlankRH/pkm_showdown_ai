from smogon import SmogonMoveset
from smogon import Smogon
