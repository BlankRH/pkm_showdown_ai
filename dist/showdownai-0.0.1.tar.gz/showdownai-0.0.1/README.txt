// single files
    .gitignore:
        files not add to git version management

    LICENSE:
        License

    Makefile:
        compile

    MANIFEST.in:
        define the list of files to include in the distribution built by the sdist command

    requirement.txt:
        required libraries

    setup.py:
        setup module showdown.ai

    showdownai.spec:
        something about framework

// datas
    teams: Pokemon teams
    smogon: gathering datas from a website, saved in ./data
    data: most data

// web
    lib: chromedriver & phantomjs
    pokemonitor: some frontend thing
    server: some frontend thing again, maybe related to web console
    showdown_ai: updated browser.py

//!!!!!
    showdownai: game and ai
